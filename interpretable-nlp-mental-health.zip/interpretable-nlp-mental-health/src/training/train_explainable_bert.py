import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import torch
from sklearn.model_selection import train_test_split
from transformers import AutoTokenizer, Trainer, TrainingArguments
from preprocessing.build_dataset import load_and_prepare
from models.explainable_bert import ExplainableBertDistress
from datasets import Dataset

LABEL_MAP = {"Non-Distress": 0, "Distress": 1}

def tokenize(tokenizer, batch):
    return tokenizer(
        batch["text"],
        padding="max_length",
        truncation=True,
        max_length=128
    )

def train():
    df = load_and_prepare()
    df["labels"] = df["label_grouped"].map(LABEL_MAP)

    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=42, stratify=df["labels"]
    )

    train_ds = Dataset.from_pandas(train_df)
    test_ds = Dataset.from_pandas(test_df)

    tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
    train_ds = train_ds.map(lambda x: tokenize(tokenizer, x), batched=True)
    test_ds = test_ds.map(lambda x: tokenize(tokenizer, x), batched=True)

    train_ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
    test_ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"])

    model = ExplainableBertDistress()

    args = TrainingArguments(
        output_dir="./results",
        num_train_epochs=3,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        logging_steps=50,
        evaluation_strategy="epoch",
        save_strategy="no",
        report_to="none"
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=test_ds,
        tokenizer=tokenizer
    )

    trainer.train()

if __name__ == "__main__":
    train()
