import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import torch
from sklearn.model_selection import train_test_split
from datasets import Dataset
from transformers import Trainer, TrainingArguments
from preprocessing.build_dataset import load_and_prepare
from models.bert_baseline import load_model

LABEL_MAP = {"Non-Distress": 0, "Distress": 1}

def tokenize_dataset(tokenizer, dataset):
    def tokenize(batch):
        return tokenizer(
            batch["text"],
            padding="max_length",
            truncation=True,
            max_length=128
        )
    return dataset.map(tokenize, batched=True)

def train():
    df = load_and_prepare()
    df["labels"] = df["label_grouped"].map(LABEL_MAP)

    train_df, test_df = train_test_split(
        df, test_size=0.2, random_state=42, stratify=df["labels"]
    )

    train_ds = Dataset.from_pandas(train_df)
    test_ds = Dataset.from_pandas(test_df)

    tokenizer, model = load_model()
    train_ds = tokenize_dataset(tokenizer, train_ds)
    test_ds = tokenize_dataset(tokenizer, test_ds)

    train_ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"])
    test_ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"])

    args = TrainingArguments(
        output_dir="./results",
        num_train_epochs=2,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        logging_steps=50,
        evaluation_strategy="epoch",
        save_strategy="no",
        report_to="none"
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=test_ds,
        tokenizer=tokenizer
    )

    trainer.train()

if __name__ == "__main__":
    train()
