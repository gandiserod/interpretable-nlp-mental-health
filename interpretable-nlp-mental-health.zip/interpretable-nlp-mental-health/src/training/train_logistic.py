import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from preprocessing.build_dataset import load_and_prepare
from models.logistic_baseline import build_model

def train():
    df = load_and_prepare()
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label_grouped"],
        test_size=0.2, random_state=42, stratify=df["label_grouped"]
    )

    vectorizer, model = build_model()
    X_train_vec = vectorizer.fit_transform(X_train)
    X_test_vec = vectorizer.transform(X_test)

    model.fit(X_train_vec, y_train)
    preds = model.predict(X_test_vec)

    print(classification_report(y_test, preds))

if __name__ == "__main__":
    train()
