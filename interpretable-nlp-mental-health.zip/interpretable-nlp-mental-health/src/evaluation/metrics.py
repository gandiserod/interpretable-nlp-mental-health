from sklearn.metrics import accuracy_score, f1_score, classification_report

def compute_metrics(y_true, y_pred):
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "f1": f1_score(y_true, y_pred)
    }

def print_report(y_true, y_pred, labels):
    print(classification_report(y_true, y_pred, target_names=labels))
