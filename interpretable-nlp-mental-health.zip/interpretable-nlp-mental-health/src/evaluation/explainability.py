import shap

def explain_model(predict_fn, texts):
    explainer = shap.Explainer(
        predict_fn,
        shap.maskers.Text()
    )
    shap_values = explainer(texts[:5])
    for i in range(len(shap_values)):
        shap.plots.text(shap_values[i])
