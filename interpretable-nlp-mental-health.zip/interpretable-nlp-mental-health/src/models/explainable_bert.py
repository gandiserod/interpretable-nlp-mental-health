import torch
import torch.nn as nn
from transformers import AutoModel
from transformers.modeling_outputs import SequenceClassifierOutput

class AttentionLayer(nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        self.attention = nn.Linear(hidden_dim, 1)

    def forward(self, inputs, mask=None):
        scores = self.attention(inputs).squeeze(-1)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e4)
        weights = torch.softmax(scores, dim=-1)
        context = torch.sum(inputs * weights.unsqueeze(-1), dim=1)
        return context, weights

class ExplainableBertDistress(nn.Module):
    def __init__(self, bert_name="bert-base-uncased"):
        super().__init__()
        self.bert = AutoModel.from_pretrained(bert_name)
        hidden = self.bert.config.hidden_size
        self.attention = AttentionLayer(hidden)
        self.fc = nn.Linear(hidden, 2)

    def forward(self, input_ids, attention_mask, labels=None):
        outputs = self.bert(input_ids=input_ids, attention_mask=attention_mask)
        context, weights = self.attention(
            outputs.last_hidden_state, attention_mask
        )
        logits = self.fc(context)

        loss = None
        if labels is not None:
            loss_fn = nn.CrossEntropyLoss()
            loss = loss_fn(logits, labels)

        return SequenceClassifierOutput(
            loss=loss,
            logits=logits,
            hidden_states=outputs.last_hidden_state
        )
