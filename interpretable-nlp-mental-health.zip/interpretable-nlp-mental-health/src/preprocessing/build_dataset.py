from datasets import load_dataset
import pandas as pd

def load_and_prepare():
    dataset = load_dataset("emotion")
    df = pd.DataFrame(dataset["train"])

    label_names = dataset["train"].features["label"].names
    df["label_text"] = df["label"].apply(lambda x: label_names[x])

    distress_map = {
        "sadness": "Distress",
        "fear": "Distress",
        "anger": "Non-Distress",
        "joy": "Non-Distress",
        "love": "Non-Distress",
        "surprise": "Non-Distress"
    }

    df["label_grouped"] = df["label_text"].map(distress_map)
    return df[["text", "label_grouped"]]