## Results

This directory summarizes model performance and qualitative findings.

Reported results include:
- Classification metrics (accuracy, F1)
- Confusion matrices
- Qualitative explanation examples

Trained model weights and raw outputs are intentionally excluded.
