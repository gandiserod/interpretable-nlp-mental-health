## Experiments

This directory documents experimental configurations and modeling decisions.

Experiments include:
- Logistic Regression baseline (TF-IDF)
- Fine-tuned BERT baseline
- Explainable BERT with attention

Hyperparameter choices and ablation reasoning are discussed in the accompanying report.
